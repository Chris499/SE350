public class NullException extends Throwable{
    public NullException(String message){
        super(message);
    }
}
