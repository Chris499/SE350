public class TravelManager {
    public static void main(String[] args) throws NullException, FormatException {

        FlightManager.getInstance().createFlight();

    }


}