public interface Flight
{
    String getFlightNumber();
}